//package com.stackroute.login.feignClient;
//
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//
//
//@FeignClient(name = "API-MESSAGE",url = "localhost:7575")
//
//public interface UserProxyEmailSender {
//@PostMapping("/sendmail")
////@RequestMapping(method = RequestMethod.POST, value = "/sendmail", consumes = "application/json", produces = "application/json")
//    public abstract ResponseEntity<?> sendEmailUserRegistered(@RequestBody EmailDetails emailDetails);
//}
