//package com.stackroute.login.feignClient;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//import java.lang.annotation.Documented;
//
//
//@AllArgsConstructor @NoArgsConstructor
//@Data
//
//public class EmailDetails {
//
//    private String emailId;
//    private String name;
//
//
//}
