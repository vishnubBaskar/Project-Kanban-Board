//package com.stackroute.emailsender.rabitMqForPasswordEmail;
//
//import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class MessageConfig1 {
//    @Bean
//    public Jackson2JsonMessageConverter getMessageConvertor1(){
//        return new Jackson2JsonMessageConverter();
//    }
//}
