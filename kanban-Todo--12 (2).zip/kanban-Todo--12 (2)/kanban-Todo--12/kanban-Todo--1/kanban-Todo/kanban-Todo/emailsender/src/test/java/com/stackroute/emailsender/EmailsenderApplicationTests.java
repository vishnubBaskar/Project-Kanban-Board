package com.stackroute.emailsender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailsenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
