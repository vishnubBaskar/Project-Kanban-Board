//package com.stackroute.kanban.model;
//
//public enum TaskStatus {
//    TODO, INPROGRESS, DONE, ARCHIVE
//}
